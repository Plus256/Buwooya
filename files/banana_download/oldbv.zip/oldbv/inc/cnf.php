<?php
ob_start();
session_start();
$serv="localhost";
$db="plusbvu";
$usr="plus256dbadmin";
$pwd="Psalm%100";
$plus256="Plus256";
$network="Plus256 Network, LLC";
$slogan="Inspiring Generations";
$tagline="Transform your Business. Transform your Life";
$noscript="Enable JavaScript in your browser to have the best experience at Plus256";
$notice="Slow down, Men at work";
$profile="img/profile.png";
$cover="img/cover.jpg";
$description="We are a Network of Specialists Devoted to Providing Absolute Solutions";
$location="Novia House, Sir Apollo Kaggwa Road, Makerere";
$mob="+256 704 739 353";
$tel="+256 788 628 316";
$mail="mail@plus256.com";
$pbox="P.O. Box 23699, Kampala";
mysql_connect($serv, $usr, $pwd) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
?>