<?php
require_once("inc/cnf.php");
require_once("inc/fun.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<link rel="shortcut icon" href="fav.ico" type="image/x-icon">
<meta name="description" content="<?php echo $plus256; ?>&trade; | <?php echo $slogan; ?>" />
<meta name="keywords" content="Plus256, Inspiring, Generations, Absolute, Solutions, Transform, Business, Life" />
<link rel="stylesheet" type="text/css" href="css/glb.css" />
<link rel="stylesheet" type="text/css" href="css/mob.css" />
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="css/ie.css" />
<![endif]-->
<!--[if !IE]><!-->
<link rel="stylesheet" type="text/css" href="css/nie.css" />
<!--<![endif]-->
<title><?php echo $plus256; ?>&trade; | <?php echo $slogan; ?></title>
<!-- Inspired By FHL Systems -->
<!-- <?php echo $network; ?> -->
<!-- <?php echo $slogan; ?> -->
<script src="js/fun.js"></script>
</head>
<body onkeydown="getKey(event);">
<noscript id="noscript"><?php echo $noscript; ?></noscript>
<div id="dialog_box_overlay"></div>
<div id="dialog_box">
	<div id="dialog_box_head"></div>
    <div id="dialog_box_body"></div>
    <div id="dialog_box_foot"></div>
</div>