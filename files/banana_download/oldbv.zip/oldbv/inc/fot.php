<div id="footer">
    <div class="wrapper">
    	Copyright &copy; <?php echo date('Y'); ?> <a href="http://www.plus256.com" target="_NEW"><?php echo $network; ?></a>
    </div>
</div>    
</body>
</html>
<?php
ob_end_flush();
?>