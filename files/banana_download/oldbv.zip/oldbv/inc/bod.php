<div id="body">
	<div id="body_wrapper">
    </div>
</div>