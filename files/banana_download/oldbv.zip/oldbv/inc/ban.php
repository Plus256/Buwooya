<div id="banner">
    <div class="wrapper">
    	<div id="cover">
        	<img src="<?php echo $cover; ?>" />
        </div>
        <div id="web_home">
        	<div>Banana Village Uganda</div>
        </div>
        <div id="tagline">
        	<?php echo $tagline; ?>
        </div>
        <div id="notice">
        	<?php echo $notice; ?>
        </div>
        <div id="logo">
        	<img src="<?php echo $profile; ?>" />
        </div>
        <div id="name">
        	<?php echo $plus256; ?>
        </div>
        <div id="slogan">
        	<?php echo $slogan; ?>
        </div>
        <div id="contact">
        	<div id="tel" class="contact"><?php echo $tel; ?></div>
            <div id="mob" class="contact"><?php echo $mob; ?></div>
            <div id="mail" class="contact"><?php echo $mail; ?></div>
            <div id="pbox" class="contact"><?php echo $pbox; ?></div>
            <div id="location" class="contact"><?php echo $location; ?></div>
        </div>
        <div id="description">
        	<?php echo $description; ?>
        </div>
        <div class="but" id="msg_but" onClick="msg_dialog.render()">Message</div>
        <div id="spacer"></div>
    </div>
</div>