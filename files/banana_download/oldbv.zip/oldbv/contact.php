<?php 
$to = "bananavillage@hotmail.com";  
$name = $_REQUEST['Name'] ;
$from = $_REQUEST['Email'] ;
$business = $_REQUEST['Business'] ;
$telephone = $_REQUEST['Telephone'] ;
$comments = $_REQUEST['Comments'] ;
$newsletter = $_REQUEST['Newsletter'] ;

$headers = "From: $from"; 
$headers3 = "-f$from"; 

$fields = array();  
$fields{"Name"} = "Name"; 
$fields{"Business"} = "Business"; 
$fields{"Email"} = "Email"; 
$fields{"Telephone"} = "Telephone";
$fields{"Comments"} = "Comments";
$fields{"Newsletter"} = "Newsletter";

$body = "We have received the following information:\n\n"; foreach($fields as $a => $b){ $body .= sprintf("%20s: %s\n",$b,$_REQUEST[$a]); }

$headers2 = "From: Banana Village";
$headers4 = "-finfo@bananavillage-uganda.com";
$subject = "User request from Banana Village website.";
$subject2 = "Thank you for contacting Banana Village"; 
$autoreply = "Thank you for contacting Banana Village, we will respond as soon as possible. 

--------------------------------------------------------------------------------------------------

Kind regards

Banana Village
 
E-mails are susceptible to interference. Banana Village accepts no responsibility for information, errors or omissions in this email or use or misuse thereof. If in doubt, please verify the authenticity with the sender. It is intended for use of the named recipient(s) only.  The contents must not be disclosed to nor used by anyone other than the above-named recipient.";

if($name == '') {header( "Location: error.html" );}
else { 
if($from == '') {header( "Location: error.html" );}
else { 
if($telephone == '') {header( "Location: error.html" );}
else {
$send = mail($to, $subject, $body, $headers, $headers3); 
$send2 = mail($from, $subject2, $autoreply, $headers2, $headers4); 
if($send) 
{header( "Location: thank-you.html" );} 
else 
{header( "Location: error.html" );}
}
}
}
?>