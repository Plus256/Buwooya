<?php
require_once("inc/hed.php");
require_once("inc/ban.php");
require_once("inc/bod.php");
require_once("inc/fot.php");
?>